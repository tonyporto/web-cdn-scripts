$(function (){
  setTimeout(function (){
    window.prettyPrint();
  }, 2000); //Yuck!
});


