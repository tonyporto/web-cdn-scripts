angular.module('jtt_aping', [
    'jtt_aping_jsonloader',
    'jtt_aping_xml',
    'jtt_aping_ng_array',
    'jtt_aping_local_storage',
]);