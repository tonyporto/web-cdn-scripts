var app = angular.module('app', [
    'jtt_aping',
    'jtt_aping_youtube',
    'jtt_aping_instagram',
    'jtt_aping_facebook',
    'jtt_aping_codebird',
    'jtt_aping_vimeo',
    'jtt_aping_flickr',
    'jtt_aping_dailymotion',
    'jtt_aping_tumblr',
    'jtt_aping_rss',
    'jtt_aping_design_default'
]);